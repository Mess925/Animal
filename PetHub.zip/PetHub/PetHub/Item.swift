//
//  Item.swift
//  PetHub
//
//  Created by Han Min Thant on 26/5/26.
//

import Foundation
import SwiftData

@Model
final class Item {
    var timestamp: Date
    
    init(timestamp: Date) {
        self.timestamp = timestamp
    }
}
